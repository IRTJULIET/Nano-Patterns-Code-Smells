# Border-Collie-Optimization
Border Collie Optimization is a new metaheuristic algorithm based on the behavior of Border Collie dogs. To get an idea of how the algorithm works, you can access the multimedia presentation present in https://ieeexplore.ieee.org/document/9106341.
The code is written in Matlab2019a.
The program execution starts with borderc.m

If you think it was helpful, we would appreciate if you cite the following paper in your work.

T. Dutta, S. Bhattacharyya, S. Dey and J. Platos, "Border Collie Optimization," in IEEE Access, vol. 8, pp. 109177-109197, 2020, doi: 10.1109/ACCESS.2020.2999540
